﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI.AllControls
{
    public partial class UC_QLHS : UserControl
    {
        public UC_QLHS()
        {
            InitializeComponent();
        }

        private void UC_QLHS_Load(object sender, EventArgs e)
        {

        }
    }
}
