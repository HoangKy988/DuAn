﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class KhoanThuHS
    {
        public int MaHocSinh { get; set; }

        public string TenHocSinh { get; set; }

        public string KhoanThu { get; set; }

        public string SoTienPhaiNop { get; set; }

        public string SoTienDaNop { get; set; }

        public string SoTienHoanTra { get; set; }

        public string SoTienThuaThieu { get; set; }
    }
}
